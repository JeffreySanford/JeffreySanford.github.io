<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']			= 'تهانينا';
$lang['intro_text']			= 'تم تثبيت PyroCMS وهو جاهز للاستخدام! رجاءً سجل دخول إلى لوحة التحكم باستخدام البيانات التالية.';
$lang['email']				= 'البريد الإلكتروني';
$lang['password']			= 'كلمة المرور';
$lang['show_password']		= 'إظهار كلمة المرور؟';
$lang['outro_text']			= 'أخيراً، <strong>احذف برنامج التثبيت من الخادم</strong> حيث أن تركه موجوداً قد يُستخدم لاختراق موقعك.';

$lang['go_website']			= 'تقدم إلى الموقع';
$lang['go_control_panel']	= 'أدخل لوحة التحكم';