<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Intro';
$lang['step1']	=	'Trin #1';
$lang['step2']	=	'Trin #2';
$lang['step3']	=	'Trin #3';
$lang['step4']	=	'Trin #4';
$lang['final']	=	'Sidste Trin';

$lang['installer.passwords_match']		= "Kodeordene Matcher.";
$lang['installer.passwords_dont_match']	= "Kodeordene Matcher Ikke.";