<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']                  = 'Üdvözöllek';
$lang['thankyou']                = 'Köszönjük, hogy a PyroCMS-t választottad!';
$lang['text']                    = 'A PyroCMS telepítése nagyon egyszerű, csak kövesd lépésről-lépésre a képernyőn látott utasításokat. Ha bármilyen probléma lépne fel a telepítés során, akkor se aggódj! A telepítő elmagyarázza a teendőket.';
$lang['step1']                   = 'Első lépés';
$lang['link']                    = 'Tedd meg az első lépést!';