<?php defined('BASEPATH') or exit('No direct script access allowed');

 /**
 * Swedish translation.
 *
 * @author		marcus@incore.se
 * @package		PyroCMS  
 * @link		http://pyrocms.com
 * @date		2012-10-22
 * @version		1.1.0
 */

$lang['intro'] = 'Start';
$lang['step1'] = 'Steg #1';
$lang['step2'] = 'Steg #2';
$lang['step3'] = 'Steg #3';
$lang['step4'] = 'Steg #4';
$lang['final'] = 'Slutför';
$lang['installer.passwords_match'] = 'Anslutningen fungerar';
$lang['installer.passwords_dont_match'] = 'Anslutningen fungerar inte, kontrollera lösenord';