<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']		= 'Gratulacje';
$lang['intro_text']		= 'PyroCMS jest teraz zainstalowany i gotowy do działania! Zaloguj się do Panelu administracyjnego, używając następujących danych:';
$lang['email']			= 'E-mail';
$lang['password']		= 'Hasło';
$lang['show_password']		= 'Pokazać hasło?';
$lang['outro_text']		= 'Na końcu <strong>usuń katalog instalatora z serwera</strong>, w przeciwnym razie może on być wykorzystany do przejęcia kontroli nad Twoim serwisem!';

$lang['go_website']		= 'Przejdź do strony';
$lang['go_control_panel']	= 'Przejdź do Panelu administracyjnego';