<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'簡介';
$lang['step1']	=	'步驟一';
$lang['step2']	=	'步驟二';
$lang['step3']	=	'步驟三';
$lang['step4']	=	'步驟四';
$lang['final']	=	'最後一步';

$lang['installer.passwords_match']		= "密碼符合";
$lang['installer.passwords_dont_match']	= "密碼不符合";