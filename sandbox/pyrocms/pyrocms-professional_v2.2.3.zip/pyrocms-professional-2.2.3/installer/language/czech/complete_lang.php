<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Gratulujeme';
$lang['intro_text']			= 'PyroCMS je nyní nainstalován a připraven! Přihlašte se prosím do administračního panelu s následujícími údaji.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Heslo';
$lang['show_password']		= 'Ukázat heslo';
$lang['outro_text']			= 'Na závěr <strong>vymžete instalátor ze serveru</strong>, pokud ho tam necháte, bude váš web napadnutelný.';

$lang['go_website']			= 'Přejít na web';
$lang['go_control_panel']	= 'Přejít do kontrolního panelu';