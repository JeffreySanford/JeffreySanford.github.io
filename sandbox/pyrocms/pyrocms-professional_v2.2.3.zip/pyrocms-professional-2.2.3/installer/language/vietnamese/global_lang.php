<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Giới thiệu';
$lang['step1']	=	'Bước #1';
$lang['step2']	=	'Bước #2';
$lang['step3']	=	'Bước #3';
$lang['step4']	=	'Bước #4';
$lang['final']	=	'Hoàn tất';

$lang['installer.passwords_match']		= 'Mật khẩu xác nhận thành công.';
$lang['installer.passwords_dont_match']	= 'Mật khẩu xác nhận không chính xác.';