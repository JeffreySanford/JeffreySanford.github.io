<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']           = 'Gratulation';
$lang['intro_text']         = 'PyroCMS wurde erfolgreich installiert und nun f&uuml;r Sie bereit! Bitte melden Sie sich mit folgenden Informationen im Admin-Bereich an.';
$lang['email']              = 'E-Mail';
$lang['password']           = 'Passwort';
$lang['show_password']      = 'Passwort zeigen?';
$lang['outro_text']         = 'Abschlie&szlig;end, <strong>l&ouml;sche den Installer-Ordner vom Server</strong>. Ihn zu belassen birgt Riskiken in der Sicherheit Ihrer Seite.';

$lang['go_website']         = 'Seite &ouml;ffnen';
$lang['go_control_panel']   = 'Adminbereich &ouml;ffnen';