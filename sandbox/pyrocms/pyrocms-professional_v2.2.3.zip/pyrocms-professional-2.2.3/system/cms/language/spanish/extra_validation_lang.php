<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']	    = "El campo %s debe contenter sólo caracteres alfanuméricos, guiones bajos, puntos y guiones.";
$lang['decimal']	        = "El campo %s debe contener sólo numeros decimales.";
$lang['csrf_bad_token']	    = "Código de CSRF inválido";

/* End of file extra_validation_lang.php */