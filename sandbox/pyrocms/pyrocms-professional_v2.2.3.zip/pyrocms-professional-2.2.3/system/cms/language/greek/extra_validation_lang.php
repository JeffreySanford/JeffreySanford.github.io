<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "Το πεδίο %s μπορεί δέχεται μόνο γράμματα, αριθμούς, κάτω παύλες, τελείες και παύλες.";
$lang['decimal']				= "Το πεδίο %s μπορεί δέχεται μόνο δεκαδικούς αριθμούς.";
$lang['csrf_bad_token']			= "Μη έγκυρο CSRF Token";

/* End of file extra_validation_lang.php */