<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "%s kenttä tulee sisältää vain aakkoskirjaimia, numeroita, alaviivoja, pisteitä sekä viivoja.";
$lang['decimal']				= "%s kenttä tulee olla desimaalinen luku.";
$lang['csrf_bad_token']			= "CSRF tunniste ei kelpaa";

/* End of file extra_validation_lang.php */