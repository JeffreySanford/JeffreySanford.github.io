<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * PyroCMS
 *
 * An open source CMS based on CodeIgniter
 *
 * @package		PyroCMS
 * @author		PyroCMS Dev Team
 * @license		Apache License v2.0
 * @link		http://pyrocms.com
 * @since		Version 1.0
 * @filesource
 */

$lang['buttons:submit']		= 'Tallenna';
$lang['buttons:cancel']		= 'Peruuta';
$lang['buttons:upload']		= 'Lataa';
$lang['buttons:save']		= 'Tallenna';
$lang['buttons:save_exit']	= 'Tallenna &amp; poistu';
$lang['buttons:delete']		= 'Poista';
$lang['buttons:publish']	= 'Julkaise';
$lang['buttons:approve']	= 'Hyväksy';
$lang['buttons:unapprove']	= 'Hylkää';
$lang['buttons:install'] 	= 'Asenna';
$lang['buttons:uninstall'] 	= 'Poista asennus';
$lang['buttons:enable']		= 'Päälle';
$lang['buttons:disable'] 	= 'Pois päältä';
$lang['buttons:yes']		= 'Kyllä';
$lang['buttons:no']			= 'Ei';
$lang['buttons:activate']   = 'Aktivoi';
$lang['buttons:deactivate']	= 'Deaktivoi';
$lang['buttons:preview']	= 'Esikatsele';
$lang['buttons:close']		= 'Sulje';
$lang['buttons:edit']		= 'Muokkaa';
$lang['buttons:clone']		= 'Kloonaa';
$lang['buttons:re-index']	= 'Indeksoi uudelleen';
$lang['buttons:copy']		= 'Kopioi';
$lang['buttons:filter']		= 'Suodata';
$lang['buttons:clear']		= 'Tyhjennä';

/* End of file buttons_lang.php */