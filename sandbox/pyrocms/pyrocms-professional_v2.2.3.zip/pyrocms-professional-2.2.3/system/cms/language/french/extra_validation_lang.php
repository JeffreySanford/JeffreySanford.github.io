<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= 'Le champ %s ne peut contenir que des caractères : alpha-numériques, tirets-bas, points et tirets.';
$lang['decimal']				= 'Le champ %s ne peut contenir que des nombres décimaux.';
$lang['csrf_bad_token']			= 'Le jeton CSRF est invalide';

/* End of file extra_validation_lang.php */