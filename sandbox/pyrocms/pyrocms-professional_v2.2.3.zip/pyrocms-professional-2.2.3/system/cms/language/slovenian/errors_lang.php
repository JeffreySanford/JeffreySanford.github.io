<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Stran ne obstaja';
$lang['error_404_message'] = 'Ne moremo najti strani katero ste iskali, prosimo kliknite <a href="%s">tukaj</a> za ogled prve strani.';

// Database
$lang['error_invalid_db_group'] = 'Podatkovna baza želi uporabiti neveljavno skupino "%s".';

/* End of file errors_lang.php */