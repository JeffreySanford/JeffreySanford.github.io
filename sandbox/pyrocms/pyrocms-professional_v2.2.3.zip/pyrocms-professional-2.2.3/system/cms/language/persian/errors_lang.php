<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'صفحه ورد نظر یافت نشد';
$lang['error_404_message'] = 'ما نتوانستیم صفحه مورد نظر شما را بیابیم، برای بازگشت به صفحه اصلی  <a href="%s">اینجا</a> کلیک نمایید.';

// Database
$lang['error_invalid_db_group'] = 'پایگاه داده سعی دارد که از گروه تنظیمات "%s" که اشتباه است استفاده کند.';

/* End of file errors_lang.php */