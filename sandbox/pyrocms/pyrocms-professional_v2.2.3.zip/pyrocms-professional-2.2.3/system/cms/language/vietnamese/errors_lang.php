<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Không tìm thấy';
$lang['error_404_message'] = 'Trang bạn cần tìm không tồn tại, vui lòng bấm vào <a href="%s">đây</a> để quay lại trang chủ.';

// Database
$lang['error_invalid_db_group'] = 'Cơ sở dữ liệu đang sử dụng cấu hình nhóm "%s" chưa đúng.';

/* End of file errors_lang.php */