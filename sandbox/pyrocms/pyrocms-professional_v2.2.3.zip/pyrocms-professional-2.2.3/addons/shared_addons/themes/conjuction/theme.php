<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Theme_Conjuction extends Theme {

    public $name = 'Conjuction';
    public $author = 'Free CSS Templates';
    public $author_website = 'http://freecsstemplates.org';
    public $website = 'http://www.freecsstemplates.org/preview/conjuction';
    public $description = '2-column, fixed; horizontal nav.';
    public $version = '1.0.0';

}

/* End of file theme.php */