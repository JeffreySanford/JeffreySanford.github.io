/*jsl:import https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js*/
/*global $, d3*/

(function () {
    'use strict';
    var data = [];
    //helper functions

    $.fn.fadeOutAndRemove = function (speed) {
        $(this).fadeOut(speed, function () {
            $(this).remove();
        });
    };

    function occupations(data) {

        $('#projectFourImage').fadeOutAndRemove(2000);
        data = data.occupations;
    }

    function firstMonth(data) {
    //  area chart : http://bl.ocks.org/mohamed-ali/ed4772df6dca7a48f678
        data = data.responses;

        $('#projectThreeImage').fadeOutAndRemove(2000);

        var margin = {top: 20, right: 20, bottom: 30, left: 50},
            width = 480- margin.left - margin.right,
            height = 300 - margin.top - margin.bottom;

        var parseDate = d3.time.format("%d-%b-%y").parse;

        var x = d3.time.scale()
            .range([0, width]);

        var y = d3.scale.linear()
            .range([height, 0]);

        var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom");

        var yAxis = d3.svg.axis()
            .scale(y)
            .orient("left");

        var area = d3.svg.area()
            .x(function (d) {
                return x(d.receive_date);
            })
            .y0(height)
            .y1(function (d) {
                return y(d.responses);
            });

        var svg = d3.select("body")
            .append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        data.forEach(function (d) {
            d.receive_date = parseDate(d.receive_date);
            d.responses = +d.responses;
        });

        x.domain(d3.extent(data, function (d) {
            return d.receive_date;
        }));
        y.domain([0, d3.max(data, function (d) {
            return d.responses;
        })]);

        svg.append("path")
            .datum(data)
            .attr("class", "area")
            .attr("d", area);

        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis);

        svg.append("g")
            .attr("class", "y axis")
            .call(yAxis)
            .append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", 6)
            .attr("dy", ".71em")
            .style("text-anchor", "end")
            .text("Responses");
    }

    function makeTable(array) {
        var i, j, row, cell;

        var table = document.createElement('table');
        for (i = 0; i < array.length; i += 1) {

            row = document.createElement('tr');

            for (j = 0; j < array[i].length; j += 1) {
                cell = document.createElement('td');
                cell.textContent = array[i][j];
                row.appendChild(cell);
            }

            table.appendChild(row);
        }
        return table;
    }

    function top5Counties(data) {

        var headers = [];
        var rows = [];
        var cellData = [];
        var i;

        $('#projectTwoImage').fadeOutAndRemove(2000);

        for (i = 0; i < data.countries.length; i += 1) {

            if (i === 0) {
                headers = [{country: "&nbsp"}];
            }
            headers = [
                {country: data.countries[i].country}
            ];

            cellData = [
                {country: data.countries[i].country},
                {responses: data.countries[i].responses}
            ];
        }

        for (i = 0; i < cellData.length; i += 1) {
            rows = [
                {label: "country", country: cellData[i].country},
                {label: "reponses", responses: cellData[i].responses}
            ];
        }

        makeTable(headers, cellData);
    }

    function totals(data) {
        var width, height;
        data = [{name: "one", value: data.count}];
        var count = data[0].value;


        //turn off the image
        $('#projectOneImage').fadeOutAndRemove(2000);
        //add the SVG target

        var margin = {top: 20, right: 20, bottom: 20, left: 20};
        width = 200 - margin.left - margin.right;
        height = width - margin.top - margin.bottom;

        var chart = d3.select("#projectOne")
            .append('svg')
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .attr("center-block", true)
            .append("g")
            .attr("transform", "translate(" + ((width / 2) + margin.left) + "," + ((height / 2) + margin.top) + ")");

        var radius = Math.min(width, height) / 2;

        var color = d3.scale.ordinal()
            .range(["#3399FF", "#5DAEF8", "#86C3FA", "#ADD6FB", "#D6EBFD"]);

        var arc = d3.svg.arc()
            .outerRadius(radius)
            .innerRadius(radius - 20);

        var pie = d3.layout.pie()
            .sort(null)
            .startAngle(1.1 * Math.PI)
            .endAngle(3.1 * Math.PI)
            .value(function (d) {
                return d.value;
            });

        var g = chart.selectAll(".arc")
            .data(pie(data))
            .enter().append("g")
            .attr("class", "arc");

        g.append("path")
            .attr("fill", function (d, i) {
                return color(i);
            })
            .transition()
            .ease("exp")
            .duration(2000)
            .attrTween("d", tweenPie);

        //Add the SVG Text Element to the svgContainer
        var text = chart.selectAll("text")
            .data(data)
            .enter()
            .append("text")
            .text(count)
            .attr("font-family", "sans-serif")
            .attr("font-size", "30px")
            .attr("font-weight", "strong")
            .attr("fill", "black");

        function tweenPie(b) {
            var i = d3.interpolate({startAngle: 1.1 * Math.PI, endAngle: 1.1 * Math.PI}, b);
            return function (t) {
                return arc(i(t));
            };
        }
    }

    function init() {

        console.log("init fired");
        var index;

        var links = ['data/count.json', 'data/top5.json', 'data/firstmonth.json', 'data/occupations.json'];

        $.each(links, function (index, value) {
            console.log(index + ": " + value);
            var url = value;
            console.log(url);

            d3.json(url, function (error, json) {
                if (error) {
                    return console.warn(error);
                }

                data = json;

                if (index === 0) {

                    console.log("fired index 1");
                    totals(data);

                } else if (index === 1) {

                    console.log("fired index 2");
                    top5Counties(data);

                } else if (index === 2) {

                    console.log("fired index 3");
                    firstMonth(data);

                } else if (index === 3) {

                    console.log("fired index 4");
                    occupations(data);

                }
            });
        });
    }

    $(document).ready(function () {
        console.log("ready!");
        init();
    });
}());