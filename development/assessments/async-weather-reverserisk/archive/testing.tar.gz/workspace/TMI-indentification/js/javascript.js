(function () {
    "use strict";
    var base = "../../site/";
    var testingPagesArray = [
        base + 'page-one.html',
        base + 'page-two.html',
        base + 'page-three.html',
        base + 'page-four.html'
    ];

    // Define some of the long DOM elements
    var testingPages = document.getElementById("testing-pages");
    var testingPage = document.getElementById("individual-pages");
    // var codeBox = page.getElementById("MainContent");
    
    window.onload = function () {
        var reqHTML = new  XMLHttpRequest();
        var individualPage = 0;
        // var reqJS = new  XMLHttpRequest();

        testingPages.innerHTML = ' ';

        for (individualPage; individualPage < testingPagesArray.length; individualPage++) {
            
            //  Target the individual webpages
            reqHTML.onreadystatechange =  function() {
                console.log(reqHTML.readyState);
            
                if (reqHTML.readyState === 4 && reqHTML.status === 200) {
            
                    var webPage = reqHTML.responseText;
                    
                    //  Show what files we are working with
                    testingPage.innerHTML += "Receive the file " + webPage.title + "<br />";
                    testingPage.innerHTML += webPage + "<br />";
                    console.log(webPage);
                    
                    //Target the javascript file(s) included in the webpage
                    var individualScript = 0, 
                        targetTags = document.getElementsByTagName("script");
                        
                    for (individualScript; individualScript < targetTags.length; individualScript++) {
                        var script = base + targetTags[individualScript];
                        
                        console.log(script);
                        testingPage.innerHTML += script.src + "<br />";
                    }
                }
            };

        reqHTML.open("GET", testingPagesArray[individualPage], false);
        reqHTML.send();
        }
    };
}());


/*  Working set
            pages.innerHTML += testingPagesArray[i];
            var targetTag = document.getElementsByTagName("script");
            targetTag.onerror = function() {
              //do something here
              pages.innerHTML += "Throwing an error."
            };
            pages.innerHTML += '<br />';
*/