(function () {
    "use strict";
    
    /*
        Setup an array of the pages to be tested.  These webpage need to be on the same server
        right now.  If not, setup  Cross-Origin Resource Sharing (CORS) to access securely across
        other servers.
     */
    var base = "../../site/";
    var testingPagesArray = [
        base + 'page-one.html',
        base + 'page-two.html',
        base + 'page-three.html',
        base + 'page-four.html'
    ];

    var displayWebPages = document.getElementById("displayWebPagesHere");
    var displayJS = document.getElementById("displayJSFilesHere");
    
    function mapAllScriptNodes(iframe) {

        console.log("iFrame object is listed here: " + iframe);
        console.log("mapAllScriptNodes fired!");

        //  Map the region on the main document to display the data
        var displayJS = document.getElementById("displayJS");
        //Returns an object of all the scripts
        var htmlCollection = iframe.getElementsByTagName("script");
        /*
            This isn't working correctly, it is supposed to only return 
            the scipt elements but it is returning the entire webpage as 
            a collection.
         */
         
        console.log("HTMLCollection is returned here: " + htmlCollection);

        //  Note an inline script is going to return a buttload of information to the screen

        var arrayOfWebPage = [].slice.call(htmlCollection);
        
        console.log("The array of the website is returned here: " + arrayOfWebPage);
        
        //  Change this
        var iFrameTitle = "iFrame Title Goes here";
    
        //  This is DOM creation stuff
        var newDiv =     document.createElement("div"),
            newInformation = document.createTextNode("For the file " + newSubject + "the follow scripts are listed:"),
            newSubject = document.createTextNode(iFrameTitle);

        //  Start writing
        newDiv.appendChild(newInformation); //  add the text node to the newly created div. 
        newDiv.appendChild(newSubject);
    }

    
    window.onload = function () {
        for (var webPage=0; webPage<testingPagesArray.length; webPage++) {
            
            console.log(testingPagesArray[webPage]);
            
            var iframe = document.createElement('iframe');
            
            iframe.src = testingPagesArray[webPage];
            iframe.onload = mapAllScriptNodes(iframe);
            displayWebPages.appendChild(iframe);
        }
    };
}());