###Second attempt

1. Identify the html and contain javascript files.
   a. start with 3 working javascript files and one broken one.
2. Display that information in a loop on the simple.html page


//testing
  //site
  //Simple
    index.html
    /js
    /css


