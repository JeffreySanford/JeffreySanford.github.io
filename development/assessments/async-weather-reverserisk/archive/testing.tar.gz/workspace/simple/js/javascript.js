(function () {
    "use strict";
    
    /*
        Setup an array of the pages to be tested.  These webpage need to be on the same server
        right now.  If not, setup  Cross-Origin Resource Sharing (CORS) to access securely across
        other servers.
     */
    var base = "../../site/";
    var testingPagesArray = [
        base + 'page-one.html',
        base + 'page-two.html',
        base + 'page-three.html',
        base + 'page-four.html'
    ];

    var displayWebPages = document.getElementById("displayWebPagesHere");
    var displayJS = document.getElementById("displayJSFilesHere");
    
    window.onload = function () {
        var reqHTML = new  XMLHttpRequest();
        var individualPage = 0;
        // var reqJS = new  XMLHttpRequest();

        displayWebPages.innerHTML = ' ';
        displayJS.innerHTML = ' ';
        
        for (individualPage; individualPage < testingPagesArray.length; individualPage++) {
            
            /*
                Target the individual webpages using SYNCronous access.  This should probably be 
                switched over to ASYNC for proper practice.  
             */
            reqHTML.onreadystatechange =  function() {
                console.log(reqHTML.readyState);  // This will current return 1 and 4, request and success.
            
                if (reqHTML.readyState === 4 && reqHTML.status === 200) {
            
                    var webPage = reqHTML.responseText;  //This is actually reutnring the entire webpage as an object.
                    
                    //  Show what files we are working with
                    displayWebPages.innerHTML += "Receive the file " + testingPagesArray[individualPage] + "<br />";
                    
                    /*
                        Create a button for this command that can be shown if the user wants more information:
                            displayWebPages.innerHTML += webPage; 
                    */
                    
                    /* console.log(webPage); */
                    
                    //Target the javascript file(s) included in the webpage
                    var individualScript = 0, 
                     // Get the script tags present in the individual HTML file.
                        /*targetTags = document.getElementsByTagName("script"); */
                        targetTags;  // *** undefined right now ***
                    
                    function targetTheScriptTags() {
                        /*  
                            At this point, we have an HTML file in the object testingPagesArray[individualPage]
                            THis is just the html, it is not actually being executed and served but rather rendered
                            on the current webpage.  If we were to excute the command 
                            targetTags = document.getElementByTagName("script");
                            it would return the javascript for the current page, not the page being scraped.
                         */
                    targetTags = testingPagesArray[individualPage];
                    }
                    
                    
                    
                    displayJS.innerHTML += " ";

                    /*  
                        For every javascript file present in the supplied HTML, loop through them and display each of them 
                     */

                    for (individualScript; individualScript < targetTags.length; individualScript++) {
                        var script = base + "js/" + targetTags[individualScript];
                        console.log
                        
                        /* 
                        console.log(script); 
                        Identifier for the HTMLScriptElement:
                        https://developer.mozilla.org/en-US/docs/Web/API/HTMLScriptElement
                         */
                         
                        displayJS.innerHTML += "<br />For the webpage (" + testingPagesArray[individualPage] + ") <br />";
                        displayJS.innerHTML += "Javascript file " + (individualScript + 1) + ": "+ script + "<br />";
                        console.log(script);
                    }
                }
            };

        reqHTML.open("GET", testingPagesArray[individualPage], false);
        reqHTML.send();
        }
    };
}());