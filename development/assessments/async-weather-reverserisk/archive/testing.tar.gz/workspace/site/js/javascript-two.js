(function() {
    var container = document.getElementById("main-content"),
    pageNumber = 2;

    container.innerHTML = "Hello World!  This is page " + pageNumber + ".";
}());