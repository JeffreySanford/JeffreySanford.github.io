(function() {
    var container = document.getElementById("MainContent"),
    pageNumber = 1;

    container.innerHTML = "Hello World!  This is page " + pageNumber + ".";
}());