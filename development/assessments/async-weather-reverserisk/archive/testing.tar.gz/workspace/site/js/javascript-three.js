(function() {
    var container = document.getElementById("main-content"),
    pageNumber = 3;

    container.innerHTML = "Hello World!  This is page " + pageNumber + ".";
}());