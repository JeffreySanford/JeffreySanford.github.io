(function() {
    var container = document.getElementById("main-content"),
    pageNumber = 4;

    container.innerHTML = "Hello World!  This is page " + pageNumber + ".";
}());